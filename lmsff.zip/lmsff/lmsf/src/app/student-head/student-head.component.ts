import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student-head',
  templateUrl: './student-head.component.html',
  styleUrls: ['./student-head.component.css']
})
export class StudentHeadComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}